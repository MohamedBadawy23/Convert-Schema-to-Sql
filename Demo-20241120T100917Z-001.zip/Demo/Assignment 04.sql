/*======================Assignment 04======================*/

/* ==Part 01== */
--Restore MyCompany Database and then:
use myCompany

--1.Display all the employees Data.

Select *
From Employee

--2.Display the employee First name, last name, Salary and Department number.

Select Fname , Lname ,Salary , Dno
From Employee

--3.Display all the projects names, locations and the department which is responsible for it.

Select P.Pname , P.Plocation , D.Dname
From Project P , Departments D
Where D.Dnum = P.Dnum

--4.If you know that the company policy is to pay an annual commission for each employee with specific percent equals 10% of his/her annual salary .Display each employee full name and his annual commission in an ANNUAL COMM column (alias).

Select CONCAT(E.Fname , ' ' , E.Lname) [Full Name] , E.Salary*12*0.1 [ANNUAL COMM]
From Employee E

--5.Display the employees Id, name who earns more than 1000 LE monthly.

Select SSN , Fname
From Employee
Where Salary > 1000

--6.Display the employees Id, name who earns more than 10000 LE annually.

Select SSN , Fname
From Employee
Where Salary*12 > 10000

--7.Display the names and salaries of the female employees 

Select Fname , Salary
From Employee
Where Sex = 'F'

--8.Display each department id, name which is managed by a manager with id equals 968574.

Select Dnum , Dname
From Departments
Where MGRSSN = 968574

--9.Display the ids, names and locations of  the projects which are controlled with department 10.

Select Pnumber , Pname , Plocation
From Project
Where Dnum = 10

/*============================================================================================================================*/
/* ==Part 02== */
--Restore ITI Database and then:
use iti

--1.Get all instructors Names without repetition

Select Distinct Ins_Name
From Instructor

--2.Display instructor Name and Department Name 
--- Note: display all the instructors if they are attached to a department or not.

Select I.Ins_Name , D.Dept_Name
From Instructor I Left join  Department D
On D.Dept_Id = I.Dept_Id

--3.Display student full name and the name of the course he is taking For only courses which have a grade  
Select CONCAT(S.St_Fname , ' ' , S.St_Lname) [Full NAme] , C.Crs_Name , Sc.Grade
From Student S , Stud_Course Sc , Course C
Where S.St_Id = Sc.St_Id and C.Crs_Id = Sc.Crs_Id and Sc.Grade is not Null

--4.Select Student first name and the data of his supervisor 

Select Stds.St_Fname , Supers.*
From Student Stds , Student Supers
Where Supers.St_Id = Stds.St_super

--5.Display student with the following Format 
--Student ID	Student Full Name	Department name

Select S.St_Id [Student ID] , CONCAT(ISNULL(S.St_Fname , 'No Name') , ' ' , ISNULL(S.St_Lname , 'No Name')) [Student Full Name] , D.Dept_Name
From Student S , Department D
Where D.Dept_Id = S.Dept_Id

--Bouns

--Display results of the following two statements and explain what is the meaning of @@AnyExpression
--select @@VERSION
select @@VERSION --sql server version

--select @@SERVERNAME
select @@SERVERNAME --server name

/*============================================================================================================================*/
/* ==Part 03== */
--Using MyCompany Database and try to  create the following Queries:
use myCompany

--1.Display the Department id, name and id and the name of its manager.

Select D.Dnum , D.Dname , Managers.SSN ,Managers.Fname
From Departments D , Employee Managers
Where Managers.SSN = D.MGRSSN

--2.Display the name of the departments and the name of the projects under its control.

Select D.Dname , P.Pname
From Departments D , Project P
Where D.Dnum = P.Dnum

--3.Display the full data about all the dependence associated with the name of the employee they depend on .

Select D.* , E.Fname [Employee Name]
From Employee E , Dependent D
Where E.SSN = D.ESSN

--4.Display the Id, name and location of the projects in Cairo or Alex city.

Select P.Pnumber , P.Pname , P.Plocation , p.City
From Project P
Where P.City in ('Cairo' , 'Alex')

--5.Display the Projects full data of the projects with a name starting with "a" letter.

Select *
From Project
Where Pname Like 'a%'

--6.display all the employees in department 30 whose salary from 1000 to 2000 LE monthly

Select *
From Employee
Where Dno = 30 and Salary between 1000 and 2000

--7.Retrieve the names of all employees in department 10 who work more than or equal 10 hours per week on the "AL Rabwah" project.

Select CONCAT(E.Fname , ' ' , E.Lname) [Employee Name]
From Employee E , Works_for WF , Project P
Where E.SSN = WF.ESSn and P.Pnumber = WF.Pno and E.Dno = 10 and WF.Hours >= 10 and P.Pname = 'AL Rabwah'

Select CONCAT(E.Fname , ' ' , E.Lname) [Employee Name]
From Employee E join Works_for WF 
On E.SSN = WF.ESSn and E.Dno = 10 and WF.Hours >=10
Join Project P 
on P.Pnumber = WF.Pno and P.Pname = 'AL Rabwah'

--8.Find the names of the employees who were directly supervised by Kamel Mohamed.

Select CONCAT(Emps.Fname , ' ' , Emps.Lname)[Employee Name] , CONCAT(Supers.Fname , ' ' , Supers.Lname) [Supervisor Name]
From Employee Emps  , Employee Supers
Where Supers.SSN = Emps.Superssn and CONCAT(Supers.Fname , ' ' , Supers.Lname) = 'Kamel Mohamed'


--9.Display All Data of the managers

Select E.*
From  Employee E , Departments D
Where E.SSN = D.MGRSSN

--10.Retrieve the names of all employees and the names of the projects they are working on, sorted by the project name.

Select E.* , P.Pname
From Employee E , Works_for WF , Project P
Where E.SSN = WF.ESSn and P.Pnumber = WF.Pno
Order By P.Pname

--11.For each project located in Cairo City , find the project number, the controlling department name ,the department manager last name ,address and birthdate

Select P.Pnumber , D.Dname , E.Lname  , E.Address , E.Bdate
From Project P , Departments D , Employee E
Where D.Dnum = P.Dnum and E.SSN = D.MGRSSN and P.City = 'Cairo'

--12.Display All Employees data and the data of their dependents even if they have no dependents.

Select E.* , D.*
From Employee E left join Dependent D
on E.SSN = D.ESSN


/*============================================================================================================================*/
/* ==Part 04== */
--Use MyCompany DB
use MyCompany

--DQL:

--1.Retrieve a list of employees and the projects they are working on ordered by department and within each department, ordered alphabetically by last name, first name.

Select *
From Employee E , Works_for WF , Project P
Where E.SSN = WF.ESSn and P.Pnumber = WF.Pno
Order By E.Dno , E.Lname , E.Fname

--2.Try to update all salaries of employees who work in Project �Al Rabwah� by 30% 

Update E
Set Salary += Salary * 0.3
From Employee E , Works_for WF , Project P
Where E.SSN = WF.ESSn and P.Pnumber = WF.Pno and P.Pname = 'Al Rabwah'

--DML:
--1.In the department table insert a new department called "DEPT IT" , with id 100, employee with SSN = 112233 as a manager for this department. The start date for this manager is '1-11-2006'.

Insert Into Departments
Values('DEPT IT',100 , 112233,'1-11-2006')

--2.Do what is required if you know that : Mrs.Noha Mohamed(SSN=968574)  moved to be the manager of the new department (id = 100), and they give you(your SSN =102672) her position (Dept. 20 manager) 

--a.First try to update her record in the department table

Update Departments
Set MGRSSN = 968574
Where Dnum =100

--b.Update your record to be department 20 manager.

Insert Into Employee (Fname , Lname , SSN)
Values('Doaa' , 'Amin' , 102672) 


----------------

Update Departments
Set MGRSSN = 102672
Where Dnum = 20


--c.Update the data of employee number=102660 to be in your teamwork (he will be supervised by you) (your SSN =102672)

Insert Into Employee (Fname , Lname , SSN)
Values('Ahmed' , 'Amr' , 102660)

Update Employee
Set Superssn = 102672
Where SSN = 102660

--3.Unfortunately the company ended the contract with  Mr.Kamel Mohamed (SSN=223344) so try to delete him from your database in case you know that you will be temporarily in his position.
--Hint: (Check if Mr. Kamel has dependents, works as a department manager, supervises any employees or works in any projects and handles these cases).

Update Employee
Set Superssn = 102672
Where Superssn = 223344

Update Works_for
Set ESSn = 102672
Where ESSn = 223344

Update Departments
Set MGRSSN = 102672
Where MGRSSN = 223344

delete Dependent
Where ESSN = 223344

delete Employee
Where SSN = 223344


/*=========================================================================================================================*/



